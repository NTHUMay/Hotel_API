/**
 * @author Yi Jyun (Eva) Chen, Yun Yung Wang
 * AndrewID: yijyunc, yunyungw
 * Email: yijyunc@andrew.cmu.edu, yunyungw@andrew.cmu.edu
 */
package ds.project4_webservice;

import java.io.*;
import java.security.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "HotelServlet", urlPatterns = {"/getHotel", ""})
public class HotelServlet extends HttpServlet {
    private String message;

    HotelModel hm = null;

    public void init() {
        hm = new HotelModel();
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String nextView;
        // if it is the /getHotel view then call API stuff

        // First timestamp
        if(request.getRequestURI().contains("getHotel")){
            String res = null;

            // get the search parameter if it exists
            String search = request.getParameter("searchWord");
            System.out.println(search);

            res = hm.callAPI(search);
            System.out.println(res);
            //response.setContentType("text/html");

            // Hello
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.println(res);
            out.flush();
        }
        // else get to the index page
        else{
            ArrayList<ArrayList<String>> readMongoDB = hm.readMongoDB();
            ArrayList<String> searchLatency = hm.getSearchLatency();
            String avg_latency = hm.getAverageLatency();
            Map<String, Integer> topCity = hm.getTopSearch();

            request.setAttribute("database", readMongoDB);
            request.setAttribute("searchLatency", searchLatency);
            request.setAttribute("avg_latency", avg_latency);
            request.setAttribute("topCity", topCity);

            nextView = "index.jsp";
            // Transfer control over the correct "view"
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }
    }

    public void destroy() {
    }
}