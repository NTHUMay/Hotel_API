/**
 * @author Yi Jyun (Eva) Chen, Yun Yung Wang
 * AndrewID: yijyunc, yunyungw
 * Email: yijyunc@andrew.cmu.edu, yunyungw@andrew.cmu.edu
 */
package ds.project4_webservice;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;


import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.result.InsertOneResult;
import org.bson.Document;
import org.bson.types.ObjectId;


public class HotelModel {
    //String fakeResponse;
    public String callAPI(String search) throws UnsupportedEncodingException {


        String res = "";

        System.out.println("**Invoke API**");

        ArrayList<HotelData> hotelList = new ArrayList<>();
        String searchTag = URLEncoder.encode(search, "UTF-8");
        // Create an API for the program to be called
        String hotelAPI =
                "https://hotels4.p.rapidapi.com/locations/v3/search?q="
                        + searchTag
                        +"&locale=en_US&langid=1033&siteid=300000001";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(hotelAPI)) // need to be replaced
                .header("X-RapidAPI-Key", "9dc453230cmshc04151d3f713057p10b9b4jsn94b589eca860")
                .header("X-RapidAPI-Host", "hotels4.p.rapidapi.com")
                .method("GET", HttpRequest.BodyPublishers.noBody())
                .build();

        HttpResponse<String> response = null;

        try {
            long apiCallTimeStamp = System.currentTimeMillis();
            response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());

            String fullLog = response.body();
            long apiResponseTimestamp = System.currentTimeMillis();
            Gson gson = new Gson();

            if (response.statusCode() == 200) {
                System.out.println("API RESULTS:");
                JsonObject jsonObject = gson.fromJson(response.body(), JsonObject.class);

                if(jsonObject.getAsJsonArray("sr").isEmpty()){
                    callMongoDB("null", fullLog, apiCallTimeStamp, apiResponseTimestamp, false);
                }else{
                    HotelData hotelData;
                    String currentCity = "";
                    JsonArray hotels = jsonObject.getAsJsonArray("sr");

                    for (JsonElement row : hotels) {
                        JsonObject rowObj = row.getAsJsonObject();
                        JsonElement type = rowObj.get("type");
                        if (type.getAsString().equals("HOTEL")) {
                            JsonObject regionNames = rowObj.getAsJsonObject("regionNames");
                            JsonElement displayName = regionNames.get("primaryDisplayName");

                            JsonObject hotelAddress = rowObj.getAsJsonObject("hotelAddress");
                            JsonElement city = hotelAddress.get("city");
                            JsonElement street = hotelAddress.get("street");
                            JsonElement province = hotelAddress.get("province");
                            currentCity = city.getAsString();
                            hotelData = new HotelData(city.getAsString(), displayName.getAsString(), street.getAsString(), province.getAsString());
                            hotelList.add(hotelData);
                            System.out.println(String.format("Hotel Name: %s, Type: %s, City: %s", displayName.getAsString(), type.getAsString(), city.getAsString()));
                        }
                    }
                    callMongoDB(currentCity, fullLog, apiCallTimeStamp, apiResponseTimestamp, true);
                    // convert array list to json format
                    res = gson.toJson(hotelList);

                    return res;//response.body();
                }

            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return "Not found!";//response.body();
    }

    public static void callMongoDB(String city, String fullLog, long apiCallTimeStamp, long apiResponseTimestamp, boolean isSuccess){

        ConnectionString connectionString = new ConnectionString("mongodb+srv://DSProject:DSProject123@cluster0.kbrdo.mongodb.net/?retryWrites=true&w=majority");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("DS");
        MongoCollection<Document> collection = database.getCollection("HotelData");

        String content = String.format("city: %s, apiCallTimeStamp: %d, apiResponseTimestamp: %d, isSuccess: %b", city,
                apiCallTimeStamp, apiResponseTimestamp, isSuccess);

        // Taken from MongoDB Docs
        // https://www.mongodb.com/docs/drivers/java/sync/v4.3/usage-examples/insertOne/
        try {
            System.out.println("Write to MongoDB: " + content);
            InsertOneResult result = collection.insertOne(new Document()
                    .append("_id", new ObjectId())
                    .append("city", city)
                    .append("fullLog", fullLog)
                    .append("apiCallTimeStamp", apiCallTimeStamp)
                    .append("apiResponseTimestamp", apiResponseTimestamp)
                    .append("isSuccess", isSuccess));
            System.out.println("Success! New Document ID: " + result.getInsertedId());
        } catch (MongoException me) {
            System.err.println("Unable to insert due to an error: " + me);
        }
    }

    public ArrayList<ArrayList<String>> readMongoDB(){

        ConnectionString connectionString = new ConnectionString("mongodb+srv://DSProject:DSProject123@cluster0.kbrdo.mongodb.net/?retryWrites=true&w=majority");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("DS");

        MongoCollection<Document> collection = database.getCollection("HotelData");
        MongoCursor<Document> docIterator = collection.find().iterator();

        if (docIterator.hasNext()) {
            System.out.println("Reading and printing all strings contained in the documents to the console:");
            StringJoiner sj = new StringJoiner("\n");
            ArrayList<ArrayList<String>> mongoDB_data = new ArrayList<ArrayList<String>>();



            while(docIterator.hasNext()) {
                Document doc = docIterator.next();
                // for each row
                ArrayList<String> mongo_DB_element = new ArrayList<>();
                mongo_DB_element.add(doc.getString("city"));
                mongo_DB_element.add(doc.getString("fullLog"));
                mongo_DB_element.add(doc.getLong("apiCallTimeStamp").toString());
                mongo_DB_element.add(doc.getLong("apiResponseTimestamp").toString());
                mongo_DB_element.add(String.valueOf(doc.getBoolean("isSuccess")));
                // append to the full database
                mongoDB_data.add(mongo_DB_element);
            }

            System.out.println("Extracted contents from documents:");
            return mongoDB_data;

        } else {
            System.out.println("There are no documents in the collection.");
            return null;
        }
    }

    public ArrayList<String> getSearchLatency(){
        // read database from MongoDB
        ArrayList<ArrayList<String>> db = readMongoDB();
        // get latency for each data
        ArrayList<String> searchLatency = new ArrayList<>();
        for(ArrayList<String> row: db){
            long start = Long.parseLong(row.get(2));
            long end = Long.parseLong(row.get(3));
            long latency_sec = (end-start)/1000;
            searchLatency.add(String.valueOf(latency_sec));
        }
        return searchLatency;
    }

    public String getAverageLatency(){
        ArrayList<String> searchLatency = getSearchLatency();
        long total = 0;
        for(String latency: searchLatency){
            long latency_long = Long.parseLong(latency);
            total += latency_long;
        }
        long avg = total/searchLatency.size();
        return String.valueOf(avg);
    }


    public Map<String, Integer> getTopSearch(){
        // read database from MongoDB
        ArrayList<ArrayList<String>> db = readMongoDB();
        Map<String, Integer> searchCityCount = new HashMap<>();
        for(ArrayList<String> row: db){
            String city = row.get(0);
            // https://mkyong.com/java/java-how-to-update-the-value-of-a-key-in-hashmap/
            searchCityCount.put(city, searchCityCount.containsKey(city) ? searchCityCount.get(city) + 1 : 1);
        }

        // Sorting reference to https://mkyong.com/java/how-to-sort-a-map-in-java/
        // 1. Convert Map to List of Map
        List<Map.Entry<String, Integer>> list =
                new LinkedList<Map.Entry<String, Integer>>(searchCityCount.entrySet());

        // 2. Sort list with Collections.sort(), provide a custom Comparator
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        // 3. Loop the sorted list and put it into a new insertion order Map LinkedHashMap
        Map<String, Integer> TopCity = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> entry : list) {
            TopCity.put(entry.getKey(), entry.getValue());
        }

//        //check
//        for (Map.Entry<String, Integer> entry : TopCity.entrySet()) {
//            System.out.println("Key : " + entry.getKey()
//                    + " Value : " + entry.getValue());
//        }
        return TopCity;
    }



}
