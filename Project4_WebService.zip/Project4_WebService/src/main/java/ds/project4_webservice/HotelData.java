/**
 * @author Yi Jyun (Eva) Chen, Yun Yung Wang
 * AndrewID: yijyunc, yunyungw
 * Email: yijyunc@andrew.cmu.edu, yunyungw@andrew.cmu.edu
 */
package ds.project4_webservice;

public class HotelData {
    String city;
    String hotelName;
    String street;
    String province;

    public HotelData(String city, String hotelName, String street, String province) {
        this.city = city;
        this.hotelName = hotelName;
        this.street = street;
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }
}
