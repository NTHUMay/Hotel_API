/**
 * @author Yi Jyun (Eva) Chen, Yun Yung Wang
 * AndrewID: yijyunc, yunyungw
 * Email: yijyunc@andrew.cmu.edu, yunyungw@andrew.cmu.edu
 */

package edu.cmu.project4_androidmobile;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class HotelInfo extends AppCompatActivity {
    HotelInfo hotelInfoOrig = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
         * The click listener will need a reference to this object, so that upon successfully finding a picture from Flickr, it
         * can callback to this object with the resulting picture Bitmap.  The "this" of the OnClick will be the OnClickListener, not
         * this InterestingPicture.
         */
        final HotelInfo hotelInfo = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);


        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
                System.out.println("searchTerm = " + searchTerm);
                GetHotel gh = new GetHotel();
                gh.search(searchTerm,hotelInfoOrig, hotelInfo); // Done asynchronously in another thread.  It calls ip.pictureReady() in this thread when complete.
            }
        });
    }

    /*
     * This is called by the GetHotel object when the result list is ready.
     */
    public void HotelListReady(ArrayList<String> hotelInfoList) {
        TextView searchView = (EditText)findViewById(R.id.searchTerm);
        TextView isFound = findViewById(R.id.isFoundResponse);
        TextView hotelListView = (TextView)findViewById(R.id.hotelInfoList);
        String searchTerm = searchView.getText().toString();
        if (hotelInfoList != null) {
            System.out.println("Hotel List");
            isFound.setText("Here is a list of a hotel in " + searchTerm);
            StringBuilder sb_list = new StringBuilder();
            for(String hotelInfo: hotelInfoList){
                sb_list.append(hotelInfo).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
            }
            hotelListView.setText(sb_list);
            hotelListView.setVisibility(View.VISIBLE);
        } else {
            System.out.println("No Hotel Result");
            isFound.setText("Sorry, no hotel result found for a " + searchTerm);
            hotelListView.setVisibility(View.INVISIBLE);
        }
        searchView.setText("");
    }

}