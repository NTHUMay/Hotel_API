/**
 * @author Yi Jyun (Eva) Chen, Yun Yung Wang
 * AndrewID: yijyunc, yunyungw
 * Email: yijyunc@andrew.cmu.edu, yunyungw@andrew.cmu.edu
 */

package edu.cmu.project4_androidmobile;
import android.app.Activity;
import org.json.JSONArray;
import org.json.JSONException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import java.util.ArrayList;


public class GetHotel {

    //Initialize variables
    HotelInfo hotelInfo = null;   // for callback
    String searchTerm = null;       // search hotel for this city
    ArrayList<String> hotelInfoList;

    // search()
    // String searchTerm: the thing to search for on flickr
    // Activity activity: the UI thread activity
    public void search(String searchTerm, Activity activity, HotelInfo hotelInfo) {
        this.hotelInfo = hotelInfo;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }

    // class BackgroundTask
    // Implements a background thread for a long running task that should not be
    //    performed on the UI thread. It creates a new Thread object, then calls doInBackground() to
    //    actually do the work. When done, it calls onPostExecute(), which runs
    //    on the UI thread to update some UI widget
    //
    // Ref
    // https://stackoverflow.com/questions/58767733/the-asynctask-api-is-deprecated-in-android-11-what-are-the-alternatives

    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    try {
                        doInBackground();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute() {
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        // doInBackground( ) implements whatever you need to do on
        //    the background thread.
        // Implement this method to suit your needs
        private void doInBackground() throws JSONException, IOException {
            hotelInfoList = search(searchTerm);
        }

        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes.
        // Implement this method to suit your needs
        public void onPostExecute() {
            hotelInfo.HotelListReady(hotelInfoList);
        }

        /*
         * Search hotel information for the searchTerm argument,
         * and return a Arraylist that can be put in an list view
         */
        private ArrayList<String> search(String searchTerm) throws IOException, JSONException {
            hotelInfoList = new ArrayList<>();
            String jsonGet = "";
            String hotelBaseURL = "https://fast-shore-28017.herokuapp.com/";
//            https://floating-fjord-37658.herokuapp.com/
            //http://localhost:8080/Project4_WebService-1.0-SNAPSHOT/getHotel?searchWord=pittsburgh
            URL url = new URL(hotelBaseURL + "getHotel?searchWord=" + searchTerm.replaceAll(" ", "%20"));
            //Basic URL formatting
            //reference https://www.tabnine.com/code/java/methods/java.net.HttpURLConnection/setRequestMethod
            HttpURLConnection connect = (HttpURLConnection) url.openConnection();
            connect.setRequestMethod("GET");
            if (connect.getResponseCode() == 200) {
                InputStreamReader reader = new InputStreamReader(connect.getInputStream());
                BufferedReader br = new BufferedReader(reader);
                String line = "";

                while ((line = br.readLine()) != null) {
                    jsonGet = jsonGet + line;
                }
                // reference https://stackoverflow.com/questions/22461663/convert-inputstream-to-jsonobject
                JSONArray jsonObject = new JSONArray(jsonGet);
                // reference https://stackoverflow.com/questions/58480521/how-to-count-json-object-item
                // looping through All Selections
                int totalCityHotel = jsonObject.length();
                System.out.println((totalCityHotel));

                for(int i=0; i<totalCityHotel; i++){
                    String hotelName = jsonObject.getJSONObject(i).get("hotelName").toString();
                    String street = jsonObject.getJSONObject(i).get("street").toString();
                    String province = jsonObject.getJSONObject(i).get("province").toString();

                    StringBuilder sb = new StringBuilder();
                    sb.append("Hotel Name: ").append(hotelName).append(System.getProperty("line.separator")).append("Street: ").append(street).append(System.getProperty("line.separator")).append("Province: ").append(province);
                    System.out.println(sb.toString());

                    hotelInfoList.add(sb.toString());
                }

                return hotelInfoList;
            }
            return null;
        }
    }
}

